import React, { useState, useRef } from 'react';
import './MyComponent.css'

const MyComponentsFunc = ({ name, children }) => {
    //useState()가 리턴하는 상태변수와 Setter함수를 선언
    const [value, setValue] = useState(0);
    const [inputs, setInputs] = useState({
        message: '',
        username: ''
    });
    const { message, username } = inputs;

    const [messages, setMessages] = useState(['Angular', 'React', 'Vue', 'Ember']);
    const messageList = messages.map(
        (msg, idx) =>
            (<li key={idx} onDoubleClick={() => handleDClick(idx)}>{msg}</li>))

    const [isValid, setIsValid] = useState(false)    
     
    //Ref 변수 선언
    const myUsername = useRef(null);

    //Event Handler 함수 정의
    const handleChange = (e) => {
        setInputs({
            ...inputs,
            [e.target.name]: e.target.value
        });
    };
    const handleDClick = (idx) => {
        setMessages(messages.filter((msg, index) => idx !== index))
    }
    const handleEnter = (e) => {
        if (e.keyCode === 13) {
            setIsValid(true)
            setMessages([...messages, message])
            setInputs({ ...inputs, message: '' })
            myUsername.current.focus()
        }
    }

    return (
        <div>
            <h2>함수형컴포넌트, {name}</h2>
            {children}
            <p>State객체의 상태변수 value = {value}</p>
            <button onClick={() => setValue(value + 1)}>증가</button>
            <button onClick={() => setValue(value - 1)}>감소</button>
            <br />
            <div>
                Message = {message} <br />
                <input name="message" value={message} 
                onChange={handleChange}
                onKeyDown={handleEnter}
                 />
            </div>
            <br />
            <ul>
                {messageList}
            </ul>
            <div>
                Username = {username} <br />
                <input name="username" value={username} 
                onChange={handleChange} 
                className={isValid ? 'success':'failure'}
                ref={myUsername}
                />
            </div>
        </div>
    );
};
MyComponentsFunc.defaultProps = {
    name: "리액트 기본값"
};
export default MyComponentsFunc;