import React, { Component } from 'react';
import PropTypes from 'prop-types';
import './MyComponent.css';

class MyComponent extends Component {
    // constructor(props) {
    //     super(props);
    //     this.handleDec = this.handleDec.bind(this);
    // }
    //상태변수값을 저장하는 state 객체
    state = {
        value: 0,
        message: '',
        messages: ['Angular','React','Vue','Ember'],
        username: '',
        isValid:false
    };
    //event handler 함수선언
    //handleDec() {
    handleDec = () => {
        this.setState({
            value: this.state.value - 1
        })
    };
    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };
    handleEnter = (e) => {
        const { message, messages } = this.state;
        if(e.keyCode === 13){
            this.setState({
                isValid: true,
                messages: [...messages, message],
                message: ''      
            });
            //ref dom에 focus()
            this.myUsername.focus();
        }//if
    };
    handleDbClick = (index) => {
        const { messages } = this.state;
        this.setState({
            messages: messages.filter((msg,idx) => idx !== index)
        });
    };

    render() {
        const { name, age } = this.props;
        const { value, message, messages, username, isValid } = this.state;
        const { handleDec, handleChange, handleEnter, handleDbClick } = this;
        const messageList = messages.map(
            (msg, idx) => (<li key={idx} onDoubleClick={() => handleDbClick(idx)}>{msg}</li>)
        );

        return (
            <div>
                <h2>클래스 컴포넌트</h2>
                <h4>{name} / {age} </h4>
                <p>
                    상태변수 value = {value}
                </p>
                <button onClick={() => this.setState({
                    value: value + 1
                })}>증가</button>
                <button onClick={handleDec}>감소</button> <br />
                <div>
                    Message = {message} <br />
                    <input name="message" value={message} 
                    onChange={handleChange} 
                    onKeyDown={handleEnter}
                    />
                    <ul>
                        {messageList}
                    </ul>
                </div>
                <div>
                    Username = {username} <br />
                    <input name="username" value={username} 
                    onChange={handleChange} 
                    className={isValid ? 'success':'failure'}
                    ref={(ref) => this.myUsername = ref}
                    />
                </div>
            </div>
        );
    }
}//class

MyComponent.defaultProps = {
    name: '리액트js'
};
MyComponent.propTypes = {
    name: PropTypes.string,
    age: PropTypes.number.isRequired
};
export default MyComponent;