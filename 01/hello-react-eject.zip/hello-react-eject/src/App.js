import './App.css';
import MyComponent from './components/MyComponent';
import MyComponentFunc from './components/MyComponentFunc';

function App() {
  return (
    <div className="App">
      <MyComponent name="Reactjs" age={100} />
      <hr/>
      <MyComponentFunc name="Reactjs함수형">
        <p>함수형의 하위엘리먼트입니다</p>
      </MyComponentFunc>  
    </div>
  );
}

export default App;
